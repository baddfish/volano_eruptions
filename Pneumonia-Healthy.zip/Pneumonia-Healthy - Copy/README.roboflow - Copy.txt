
COVID-19 and Pneumonia Scans - v1 resize-416x416-reflect
==============================

This dataset was exported via roboflow.ai on April 9, 2020 at 6:56 PM GMT

It includes 5887 images.
X-rays are annotated in folder format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Fit (reflect edges))

No image augmentation techniques were applied.


