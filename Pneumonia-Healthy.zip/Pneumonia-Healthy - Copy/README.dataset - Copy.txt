# COVID-19 and Pneumonia Scans > resize-416x416-reflect
https://public.roboflow.ai/classification/covid-19-and-pneumonia-scans

Provided by [Linda Wangg](https://github.com/lindawangg/COVID-Net)
License: Public Domain

# Please read more about this release [here](https://blog.roboflow.ai/using-computer-vision-to-fight-coronavirus-covid-19/) Thank you.

Note: results generated from this dataset should not be considered diagnostic.

Significant credit to researchers making their efforts available in [COVID-Net](https://github.com/lindawangg/COVID-Net).